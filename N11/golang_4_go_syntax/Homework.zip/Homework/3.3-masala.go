package main



func main() {
	var month int

	month = 2

	switch month {
	case 1:
		println(" yanvar ")
	case 2:
		println(" fevral ")
	case 3:
		println(" mart ")
	case 4:
		println(" aprel ")
	case 5:
		println(" may ")
	case 6:
		println(" iyun ")
	case 7:
		println(" iyul ")
	case 8:
		println(" avgust ")
	case 9:
		println(" sentabr ")
	case 10:
		println(" oktabr ")
	case 11:
		println(" noyabr ")
	case 12:
		println(" dekabr ")
	default:
		println("Noto'g'ri oy raqami kiritildi.")
	}

}
