package main

import "fmt"

func main() {
	var target int = 57 
	var guess int  = 57


		if guess == target {
			fmt.Println("Tabriklayman, siz topdingiz!")
		} else {
			fmt.Println("Boshqattan urunib ko'ring")
			}


}

