package tasks

func Abs(num int) int {
	if num < 0 {
		return -num
	}
	return num
}
