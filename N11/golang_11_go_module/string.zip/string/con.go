package string

func ConcatenateTwo(str1 string, str2 string) string {
    n := str1 + str2
    return n
}