package main

func main(){
	var r rune = 'A'
	var b byte = 'A'

	println(r)
	println(b)
}

/* rune turi: Bu tur matn belgilari (Unicode code point) uchun ishlatiladi. 
Har bir rune bir harfni ifodalaydi.
rune turining asosiy maqsadi matnning unicode formatidagi belgilarni saqlash 
va ularni dastur ichida ko'rsatishdir.*/

/*byte turi matnlarni asosiy ravishda ifodalash uchun ishlatiladi 
va uni qanday ishlatishizga qarab matn belgilari va 
bayt qiymatlari orasidagi bog'lanishni tushunishingiz mumkin.*/
