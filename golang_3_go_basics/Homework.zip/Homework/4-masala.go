package main

func main() {
    println("1 ning kvadrati:", square(1))
    println("2 ning kvadrati:", square(2))
    println("3 ning kvadrati:", square(3))
    println("4 ning kvadrati:", square(4))
    println("5 ning kvadrati:", square(5))
    println("6 ning kvadrati:", square(6))
    println("7 ning kvadrati:", square(7))
    println("8 ning kvadrati:", square(8))
    println("9 ning kvadrati:", square(9))
    println("10 ning kvadrati:", square(10))
}

func square(num int) int {
    return num * num
}
