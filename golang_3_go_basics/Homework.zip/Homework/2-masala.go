package main

func main() {
    var ism = "Hojiakbar"
    var familya = "Abbosov"

    birlashgan := ism + " " + familya
	print(birlashgan)
}
