package main

func main() {
    println(5*3)

    println(3.5*2.5)

    println(10/3)

    println(10.0/3.0)
}
