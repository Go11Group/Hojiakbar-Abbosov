package main

func main() {
    birthYear := 2006

    currentYear := 2024

    age := currentYear - birthYear

    println(age)
}
